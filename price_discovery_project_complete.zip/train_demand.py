import pandas as pd
import joblib
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

DATA_FILE = "ecommerce_price_discovery_dataset.csv"
MODEL_FILE = "demand_model.pkl"

FEATURES = [
    "selling_price","previous_price","competitor_price","competitor_gap_pct",
    "discount_pct","price_change_pct","rating","review_count","seller_rating",
    "page_views","add_to_cart_rate","conversion_rate","promotion",
    "festival_event","holiday","day_of_week","month","quarter","week_of_year",
    "inventory_start","inventory_end","inventory_pressure",
    "lag_1_units_sold","lag_7_units_sold","rolling_7d_units_sold",
    "rolling_30d_units_sold","shipping_days"
]
TARGET = "units_sold"

print("Loading dataset...")
data = pd.read_csv(DATA_FILE, parse_dates=["date"])
data = data.sort_values(["date","product_id"]).reset_index(drop=True)

# Chronological split prevents future-data leakage.
split_date = data["date"].quantile(0.80)
train = data[data["date"] < split_date]
test = data[data["date"] >= split_date]

model = XGBRegressor(
    n_estimators=300, max_depth=8, learning_rate=0.05,
    subsample=0.85, colsample_bytree=0.85,
    objective="reg:squarederror", random_state=42, n_jobs=-1
)
model.fit(train[FEATURES], train[TARGET])

pred = model.predict(test[FEATURES]).clip(min=0)
mae = mean_absolute_error(test[TARGET], pred)
rmse = mean_squared_error(test[TARGET], pred) ** 0.5
r2 = r2_score(test[TARGET], pred)

print("\nDemand Model Results")
print(f"Training rows: {len(train):,}")
print(f"Testing rows : {len(test):,}")
print(f"MAE : {mae:.3f}")
print(f"RMSE: {rmse:.3f}")
print(f"R2  : {r2:.4f}")

joblib.dump({"model": model, "features": FEATURES}, MODEL_FILE)
print(f"Saved: {MODEL_FILE}")
