PRICE DISCOVERY PROJECT

Keep these files and ecommerce_price_discovery_dataset.csv in the same folder.

Run:
1. python -m pip install -r requirements.txt
2. python train_demand.py
3. python train_dqn.py
4. python recommend_price.py
5. python recommend_price.py --product LAP001
6. python evaluate_pricing.py --product LAP001
7. python -m streamlit run app.py

Generated models:
- demand_model.pkl
- dqn_pricing_model.pth

The supplied e-commerce dataset is synthetic for an academic prototype.
