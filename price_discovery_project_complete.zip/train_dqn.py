import random
from collections import deque
import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from pricing_environment import PricingEnvironment
from dqn_model import DQN

DATA_FILE="ecommerce_price_discovery_dataset.csv"
DEMAND_MODEL_FILE="demand_model.pkl"
DQN_FILE="dqn_pricing_model.pth"
STATE_SIZE=14
ACTION_SIZE=3
EPISODES=80
BATCH_SIZE=64
GAMMA=0.95
LR=0.0005
EPSILON=1.0
EPSILON_MIN=0.05
EPSILON_DECAY=0.97
MEMORY_SIZE=20000

device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
data=pd.read_csv(DATA_FILE,parse_dates=["date"]).sort_values(["product_id","date"]).reset_index(drop=True)
demand_model=joblib.load(DEMAND_MODEL_FILE)["model"]
products=data.product_id.unique().tolist()

policy=DQN(STATE_SIZE,ACTION_SIZE).to(device)
target=DQN(STATE_SIZE,ACTION_SIZE).to(device)
target.load_state_dict(policy.state_dict())
target.eval()
optimizer=optim.Adam(policy.parameters(),lr=LR)
loss_fn=nn.SmoothL1Loss()
memory=deque(maxlen=MEMORY_SIZE)

def choose_action(state, epsilon):
    if random.random()<epsilon:
        return random.randrange(ACTION_SIZE)
    with torch.no_grad():
        x=torch.tensor(state,dtype=torch.float32,device=device).unsqueeze(0)
        return int(policy(x).argmax(1).item())

def train_batch():
    if len(memory)<BATCH_SIZE: return None
    batch=random.sample(memory,BATCH_SIZE)
    s,a,r,ns,d=zip(*batch)
    s=torch.tensor(np.array(s),dtype=torch.float32,device=device)
    a=torch.tensor(a,dtype=torch.long,device=device).unsqueeze(1)
    r=torch.tensor(r,dtype=torch.float32,device=device)
    ns=torch.tensor(np.array(ns),dtype=torch.float32,device=device)
    d=torch.tensor(d,dtype=torch.float32,device=device)
    q=policy(s).gather(1,a).squeeze(1)
    with torch.no_grad():
        target_q=r+GAMMA*target(ns).max(1).values*(1-d)
    loss=loss_fn(q,target_q)
    optimizer.zero_grad(); loss.backward()
    torch.nn.utils.clip_grad_norm_(policy.parameters(),1.0)
    optimizer.step()
    return loss.item()

epsilon=EPSILON
for episode in range(1,EPISODES+1):
    pid=random.choice(products)
    env=PricingEnvironment(data,demand_model,pid,max_steps=30)
    state=env.reset()
    total=0; losses=[]
    for _ in range(30):
        action=choose_action(state,epsilon)
        ns,reward,done,info=env.step(action)
        memory.append((state,action,reward,ns,done))
        loss=train_batch()
        if loss is not None: losses.append(loss)
        state=ns; total+=reward
        if done: break
    epsilon=max(EPSILON_MIN,epsilon*EPSILON_DECAY)
    if episode%10==0: target.load_state_dict(policy.state_dict())
    print(f"Episode {episode:03d} | Product {pid} | Reward {total:,.2f} | Epsilon {epsilon:.3f}")

torch.save({"model_state_dict":policy.state_dict(),
            "state_size":STATE_SIZE,"action_size":ACTION_SIZE},DQN_FILE)
print(f"Saved: {DQN_FILE}")
