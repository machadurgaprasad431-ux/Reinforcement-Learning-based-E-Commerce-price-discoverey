import numpy as np
import pandas as pd

class PricingEnvironment:
    # 0 = -5%, 1 = unchanged, 2 = +5%
    ACTIONS = {0: -0.05, 1: 0.00, 2: 0.05}

    def __init__(self, data, demand_model, product_id=None,
                 start_index=0, max_steps=30):
        self.data = data.copy()
        if product_id is not None:
            self.data = self.data[self.data["product_id"] == product_id]
        self.data = self.data.sort_values("date").reset_index(drop=True)
        if len(self.data) < 2:
            raise ValueError("Not enough rows for this product.")
        self.max_steps = max_steps
        self.start_index = min(start_index, len(self.data)-2)
        self.model = demand_model
        self.reset()

    def _row(self):
        return self.data.iloc[self.index]

    def _state(self):
        r = self._row()
        return np.array([
            r["selling_price"], r["previous_price"], r["competitor_price"],
            r["competitor_gap_pct"], r["discount_pct"], r["units_sold"],
            r["inventory_end"], r["rating"], r["page_views"],
            r["conversion_rate"], r["day_of_week"], r["month"],
            r["promotion"], r["inventory_pressure"]
        ], dtype=np.float32)

    def reset(self):
        self.index = self.start_index
        self.steps = 0
        self.current_price = float(self._row()["selling_price"])
        return self._state()

    def _features(self, row, price):
        base = float(row["base_price"])
        return pd.DataFrame([{
            "selling_price": price,
            "previous_price": row["previous_price"],
            "competitor_price": row["competitor_price"],
            "competitor_gap_pct": (price-row["competitor_price"])/row["competitor_price"]*100,
            "discount_pct": max(0, (base-price)/base*100),
            "price_change_pct": (price-row["previous_price"])/row["previous_price"]*100,
            "rating": row["rating"], "review_count": row["review_count"],
            "seller_rating": row["seller_rating"], "page_views": row["page_views"],
            "add_to_cart_rate": row["add_to_cart_rate"],
            "conversion_rate": row["conversion_rate"],
            "promotion": row["promotion"], "festival_event": row["festival_event"],
            "holiday": row["holiday"], "day_of_week": row["day_of_week"],
            "month": row["month"], "quarter": row["quarter"],
            "week_of_year": row["week_of_year"],
            "inventory_start": row["inventory_start"], "inventory_end": row["inventory_end"],
            "inventory_pressure": row["inventory_pressure"],
            "lag_1_units_sold": row["lag_1_units_sold"],
            "lag_7_units_sold": row["lag_7_units_sold"],
            "rolling_7d_units_sold": row["rolling_7d_units_sold"],
            "rolling_30d_units_sold": row["rolling_30d_units_sold"],
            "shipping_days": row["shipping_days"]
        }])

    def step(self, action):
        row = self._row()
        old_price = self.current_price
        base = float(row["base_price"])
        new_price = old_price * (1 + self.ACTIONS[int(action)])
        new_price = float(np.clip(new_price, base*0.80, base*1.20))

        bundle_features = [
            "selling_price","previous_price","competitor_price","competitor_gap_pct",
            "discount_pct","price_change_pct","rating","review_count","seller_rating",
            "page_views","add_to_cart_rate","conversion_rate","promotion",
            "festival_event","holiday","day_of_week","month","quarter","week_of_year",
            "inventory_start","inventory_end","inventory_pressure",
            "lag_1_units_sold","lag_7_units_sold","rolling_7d_units_sold",
            "rolling_30d_units_sold","shipping_days"
        ]
        X = self._features(row, new_price)[bundle_features]
        demand = max(0.0, float(self.model.predict(X)[0]))
        inventory = max(0.0, float(row["inventory_end"]))
        sales = min(demand, inventory)
        revenue = sales * new_price
        cost = float(row["unit_cost"])
        profit = sales * (new_price-cost)
        stockout_penalty = max(0, demand-inventory) * cost * 0.10
        price_change_penalty = abs(new_price-old_price) * sales * 0.01
        reward = profit + 0.05*revenue - stockout_penalty - price_change_penalty

        self.current_price = new_price
        self.steps += 1
        self.index += 1
        done = self.steps >= self.max_steps or self.index >= len(self.data)
        next_state = np.zeros(14, dtype=np.float32) if done else self._state()

        return next_state, float(reward), done, {
            "price": new_price, "predicted_demand": demand,
            "predicted_sales": sales, "revenue": revenue,
            "gross_profit": profit, "reward": reward, "inventory": inventory
        }
