import argparse
import joblib
import numpy as np
import pandas as pd
import torch
from dqn_model import DQN

ACTIONS={0:-0.05,1:0.0,2:0.05}
FEATURES=joblib.load("demand_model.pkl")["features"]

def features(row,price):
    base=row.base_price
    return pd.DataFrame([{
        "selling_price":price,"previous_price":row.previous_price,
        "competitor_price":row.competitor_price,
        "competitor_gap_pct":(price-row.competitor_price)/row.competitor_price*100,
        "discount_pct":max(0,(base-price)/base*100),
        "price_change_pct":(price-row.previous_price)/row.previous_price*100,
        "rating":row.rating,"review_count":row.review_count,
        "seller_rating":row.seller_rating,"page_views":row.page_views,
        "add_to_cart_rate":row.add_to_cart_rate,"conversion_rate":row.conversion_rate,
        "promotion":row.promotion,"festival_event":row.festival_event,"holiday":row.holiday,
        "day_of_week":row.day_of_week,"month":row.month,"quarter":row.quarter,
        "week_of_year":row.week_of_year,"inventory_start":row.inventory_start,
        "inventory_end":row.inventory_end,"inventory_pressure":row.inventory_pressure,
        "lag_1_units_sold":row.lag_1_units_sold,"lag_7_units_sold":row.lag_7_units_sold,
        "rolling_7d_units_sold":row.rolling_7d_units_sold,
        "rolling_30d_units_sold":row.rolling_30d_units_sold,
        "shipping_days":row.shipping_days}])

def predict(row,price,model):
    d=max(0,float(model.predict(features(row,price)[FEATURES])[0]))
    s=min(d,max(0,float(row.inventory_end)))
    rev=s*price
    profit=s*(price-float(row.unit_cost))
    return d,s,rev,profit

p=argparse.ArgumentParser()
p.add_argument("--product",default=None)
args=p.parse_args()

data=pd.read_csv("ecommerce_price_discovery_dataset.csv",parse_dates=["date"]).sort_values(["product_id","date"])
if args.product:
    data=data[data.product_id==args.product]
    if data.empty: raise ValueError("Product not found.")
row=data.iloc[-1]

bundle=joblib.load("demand_model.pkl")
model=bundle["model"]

ckpt=torch.load("dqn_pricing_model.pth",map_location="cpu")
dqn=DQN(ckpt["state_size"],ckpt["action_size"])
dqn.load_state_dict(ckpt["model_state_dict"]); dqn.eval()

state=np.array([row.selling_price,row.previous_price,row.competitor_price,
row.competitor_gap_pct,row.discount_pct,row.units_sold,row.inventory_end,
row.rating,row.page_views,row.conversion_rate,row.day_of_week,row.month,
row.promotion,row.inventory_pressure],dtype=np.float32)
with torch.no_grad(): q=dqn(torch.tensor(state).unsqueeze(0)).numpy()[0]
action=int(np.argmax(q))

current=float(row.selling_price)
recommended=float(np.clip(current*(1+ACTIONS[action]),row.base_price*.8,row.base_price*1.2))
c=predict(row,current,model)
r=predict(row,recommended,model)

print("\nPRICING EVALUATION")
print(f"Product: {row.product_name} ({row.product_id})")
print(f"Current price     : ₹{current:,.2f}")
print(f"Recommended price : ₹{recommended:,.2f}")
print(f"Action            : {action} ({ACTIONS[action]*100:+.0f}%)")
print(f"\nCurrent    demand={c[0]:.2f}, revenue=₹{c[2]:,.2f}, profit=₹{c[3]:,.2f}")
print(f"Recommended demand={r[0]:.2f}, revenue=₹{r[2]:,.2f}, profit=₹{r[3]:,.2f}")
print(f"\nRevenue change: ₹{r[2]-c[2]:,.2f} ({(r[2]-c[2])/c[2]*100 if c[2] else 0:+.2f}%)")
print(f"Profit change : ₹{r[3]-c[3]:,.2f} ({(r[3]-c[3])/abs(c[3])*100 if c[3] else 0:+.2f}%)")
