import joblib
import numpy as np
import pandas as pd
import streamlit as st
import torch
import plotly.express as px
from dqn_model import DQN

st.set_page_config(page_title="AI Price Discovery",page_icon="💰",layout="wide")

@st.cache_data
def load_data():
    return pd.read_csv("ecommerce_price_discovery_dataset.csv",parse_dates=["date"])

@st.cache_resource
def load_models():
    b=joblib.load("demand_model.pkl")
    ck=torch.load("dqn_pricing_model.pth",map_location="cpu")
    d=DQN(ck["state_size"],ck["action_size"])
    d.load_state_dict(ck["model_state_dict"]); d.eval()
    return b["model"],b["features"],d

data=load_data()
demand_model,feature_names,dqn=load_models()
ACTIONS={0:-.05,1:0,2:.05}

st.title("💰 Hybrid Reinforcement Learning for E-Commerce Price Discovery")
st.caption("XGBoost demand prediction + DQN pricing recommendation + simulation")

category=st.sidebar.selectbox("Category",sorted(data.category.unique()))
products=data[data.category==category].product_id.unique()
pid=st.sidebar.selectbox("Product",products)
product_data=data[data.product_id==pid].sort_values("date")
row=product_data.iloc[-1]

def make_features(price):
    b=float(row.base_price)
    return pd.DataFrame([{
        "selling_price":price,"previous_price":row.previous_price,
        "competitor_price":row.competitor_price,
        "competitor_gap_pct":(price-row.competitor_price)/row.competitor_price*100,
        "discount_pct":max(0,(b-price)/b*100),
        "price_change_pct":(price-row.previous_price)/row.previous_price*100,
        "rating":row.rating,"review_count":row.review_count,
        "seller_rating":row.seller_rating,"page_views":row.page_views,
        "add_to_cart_rate":row.add_to_cart_rate,"conversion_rate":row.conversion_rate,
        "promotion":row.promotion,"festival_event":row.festival_event,"holiday":row.holiday,
        "day_of_week":row.day_of_week,"month":row.month,"quarter":row.quarter,
        "week_of_year":row.week_of_year,"inventory_start":row.inventory_start,
        "inventory_end":row.inventory_end,"inventory_pressure":row.inventory_pressure,
        "lag_1_units_sold":row.lag_1_units_sold,"lag_7_units_sold":row.lag_7_units_sold,
        "rolling_7d_units_sold":row.rolling_7d_units_sold,
        "rolling_30d_units_sold":row.rolling_30d_units_sold,
        "shipping_days":row.shipping_days}])

def predict(price):
    d=max(0,float(demand_model.predict(make_features(price)[feature_names])[0]))
    s=min(d,max(0,float(row.inventory_end)))
    rev=s*price
    profit=s*(price-float(row.unit_cost))
    return d,s,rev,profit

state=np.array([row.selling_price,row.previous_price,row.competitor_price,
row.competitor_gap_pct,row.discount_pct,row.units_sold,row.inventory_end,
row.rating,row.page_views,row.conversion_rate,row.day_of_week,row.month,
row.promotion,row.inventory_pressure],dtype=np.float32)
with torch.no_grad(): q=dqn(torch.tensor(state).unsqueeze(0)).numpy()[0]
action=int(np.argmax(q))
current=float(row.selling_price)
recommended=float(np.clip(current*(1+ACTIONS[action]),row.base_price*.8,row.base_price*1.2))
cur=predict(current); rec=predict(recommended)

st.subheader(row.product_name)
a,b,c,d,e=st.columns(5)
a.metric("Current Price",f"₹{current:,.0f}")
b.metric("Recommended Price",f"₹{recommended:,.0f}")
c.metric("Competitor Price",f"₹{row.competitor_price:,.0f}")
d.metric("Predicted Demand",f"{rec[0]:,.1f}")
e.metric("Profit Change",f"₹{rec[3]-cur[3]:,.0f}")

st.divider()
l,r=st.columns(2)
with l:
    st.subheader("📦 Product Information")
    st.write(f"**Product ID:** {row.product_id}")
    st.write(f"**Category:** {row.category}")
    st.write(f"**Brand:** {row.brand}")
    st.write(f"**Rating:** ⭐ {row.rating}")
    st.write(f"**Reviews:** {int(row.review_count):,}")
    st.write(f"**Inventory:** {int(row.inventory_end):,}")
with r:
    st.subheader("🤖 RL Decision")
    names={0:"Decrease price by 5%",1:"Keep current price",2:"Increase price by 5%"}
    st.write(f"**Action:** {names[action]}")
    st.write(f"**Q-values:** {np.round(q,4)}")
    qdf=pd.DataFrame({"Action":["-5%","0%","+5%"],"Q-value":q})
    st.plotly_chart(px.bar(qdf,x="Action",y="Q-value",title="DQN Action Values"),
                    use_container_width=True)

st.divider()
st.subheader("📊 Price Simulation")
changes=[-10,-5,0,5,10]
sim=[]
for pct in changes:
    p=float(np.clip(current*(1+pct/100),row.base_price*.8,row.base_price*1.2))
    x=predict(p)
    sim.append({"Price Change (%)":pct,"Price":p,"Predicted Demand":x[0],
                "Predicted Sales":x[1],"Revenue":x[2],"Profit":x[3]})
simdf=pd.DataFrame(sim)
st.dataframe(simdf.style.format({"Price":"₹{:,.2f}","Predicted Demand":"{:,.2f}",
"Predicted Sales":"{:,.2f}","Revenue":"₹{:,.2f}","Profit":"₹{:,.2f}"}),
use_container_width=True)
st.plotly_chart(px.line(simdf,x="Price",y="Revenue",markers=True,title="Price vs Revenue"),
                use_container_width=True)
st.plotly_chart(px.line(simdf,x="Price",y="Predicted Demand",markers=True,title="Price vs Demand"),
                use_container_width=True)

st.divider()
st.subheader("📈 Historical Performance - Last 90 Days")
hist=product_data.tail(90)
st.plotly_chart(px.line(hist,x="date",y="selling_price",title="Selling Price"),
                use_container_width=True)
st.plotly_chart(px.line(hist,x="date",y="units_sold",title="Units Sold"),
                use_container_width=True)
